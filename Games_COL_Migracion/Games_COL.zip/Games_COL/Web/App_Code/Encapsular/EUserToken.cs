﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Descripción breve de EUserToken
/// </summary>
public class EUserToken
{
    public EUserToken()
    {
        //
        // TODO: Agregar aquí la lógica del constructor
        //
    }
    private Int32 id;
    private String nombre;
    private String correo;
    private String user_name;
    private Int32 estado;
    private long fecha;

    public int Id
    {
        get
        {
            return id;
        }

        set
        {
            id = value;
        }
    }

    public string Nombre
    {
        get
        {
            return nombre;
        }

        set
        {
            nombre = value;
        }
    }

    public string Correo
    {
        get
        {
            return correo;
        }

        set
        {
            correo = value;
        }
    }

    public string User_name
    {
        get
        {
            return user_name;
        }

        set
        {
            user_name = value;
        }
    }

    public int Estado
    {
        get
        {
            return estado;
        }

        set
        {
            estado = value;
        }
    }

    public long Fecha
    {
        get
        {
            return fecha;
        }

        set
        {
            fecha = value;
        }
    }
}