﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Utilitarios
{
     public class U_logueo
     {
        private string nick;
        private string pass;

        public string Nick { get => nick; set => nick = value; }
        public string Pass { get => pass; set => pass = value; }
    }
}
